CREATE VIEW `viewadminlog` AS
  SELECT
    `a`.`aName`          AS `adminName`,
    `b`.`adminLoginTime` AS `adminLoginTime`,
    `b`.`adminLoginIP`   AS `adminLoginIP`
  FROM `dbmall`.`admin` `a`
    JOIN `dbmall`.`admin_login_log` `b`
  WHERE (`a`.`aID` = `b`.`adminID`)