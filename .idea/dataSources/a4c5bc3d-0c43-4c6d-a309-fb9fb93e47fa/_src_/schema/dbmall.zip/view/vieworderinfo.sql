CREATE VIEW `vieworderinfo` AS
  SELECT
    `a`.`orderID`       AS `orderID`,
    `a`.`orderSumPrice` AS `orderSumPrice`,
    `a`.`orderCName`    AS `orderCName`,
    `a`.`orderAddress`  AS `orderAddress`,
    `a`.`orderPhone`    AS `orderPhone`,
    `b`.`eName`         AS `expressName`,
    `a`.`expressNum`    AS `expressNum`,
    `a`.`orderPaid`     AS `orderPaid`,
    `a`.`orderPaidBy`   AS `orderPaidBy`,
    `a`.`orderStatus`   AS `orderStatus`
  FROM `dbmall`.`order_list` `a`
    JOIN `dbmall`.`express_list` `b`
  WHERE (`a`.`expressID` = `b`.`eID`)