CREATE VIEW `vieworderinfo` AS
  SELECT
    `dbmall`.`order_list`.`orderID`       AS `orderID`,
    `dbmall`.`order_list`.`orderUserID`   AS `orderUserID`,
    `dbmall`.`users`.`uName`              AS `orderUserName`,
    `dbmall`.`order_list`.`orderSumPrice` AS `orderSumPrice`,
    `dbmall`.`order_list`.`orderCName`    AS `orderCName`,
    `dbmall`.`order_list`.`orderAddress`  AS `orderAddress`,
    `dbmall`.`order_list`.`orderPhone`    AS `orderPhone`,
    `dbmall`.`express_list`.`eName`       AS `expressName`,
    `dbmall`.`order_list`.`expressNum`    AS `expressNum`,
    `dbmall`.`order_list`.`orderPaid`     AS `orderPaid`,
    `dbmall`.`order_list`.`orderPaidBy`   AS `orderPaidBy`,
    `dbmall`.`order_list`.`orderStatus`   AS `orderStatus`
  FROM ((`dbmall`.`order_list`
    LEFT JOIN `dbmall`.`express_list`
      ON ((`dbmall`.`order_list`.`expressID` = `dbmall`.`express_list`.`eID`))) LEFT JOIN `dbmall`.`users`
      ON ((`dbmall`.`order_list`.`orderUserID` = `dbmall`.`users`.`uID`)))