CREATE VIEW `viewgoodsdetail` AS
  SELECT
    `a`.`gID`          AS `gID`,
    `a`.`gName`        AS `gName`,
    `a`.`gType`        AS `gType`,
    `b`.`tName`        AS `goodsTypeName`,
    `a`.`gPrice`       AS `gPrice`,
    `a`.`gOriginPrice` AS `gOriginPrice`,
    `a`.`gCount`       AS `gCount`,
    `a`.`gSalesSUID`   AS `gSalesSUID`,
    `c`.`shopName`     AS `shopName`,
    `a`.`gPhoto`       AS `gPhoto`,
    `a`.`gDescription` AS `gDescription`,
    `a`.`gPubTime`     AS `gPubTime`,
    `a`.`gStatus`      AS `gStatus`
  FROM `dbmall`.`goods` `a`
    JOIN `dbmall`.`goodstype` `b`
    JOIN `dbmall`.`sale_users` `c`
  WHERE ((`a`.`gType` = `b`.`tID`) AND (`a`.`gSalesSUID` = `c`.`sID`))