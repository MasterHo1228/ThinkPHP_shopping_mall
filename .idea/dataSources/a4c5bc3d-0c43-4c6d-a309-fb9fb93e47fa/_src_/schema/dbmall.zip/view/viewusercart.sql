CREATE VIEW `viewusercart` AS
  SELECT
    `a`.`userID`     AS `userID`,
    `a`.`goodsID`    AS `goodsID`,
    `b`.`gName`      AS `goodsName`,
    `b`.`gPrice`     AS `goodsPrice`,
    `b`.`gPhoto`     AS `goodsPhoto`,
    `a`.`goodsCount` AS `goodsCount`
  FROM `dbmall`.`user_cart` `a`
    JOIN `dbmall`.`goods` `b`
  WHERE (`a`.`goodsID` = `b`.`gID`)