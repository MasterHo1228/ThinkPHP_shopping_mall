CREATE VIEW `viewordergoodsinfo` AS
  SELECT
    `a`.`orderID`     AS `orderID`,
    `a`.`orderGID`    AS `orderGID`,
    `b`.`gName`       AS `goodsName`,
    `a`.`orderGCount` AS `goodsCount`,
    `b`.`gPrice`      AS `goodsPrice`
  FROM `dbmall`.`order_list_item` `a`
    JOIN `dbmall`.`goods` `b`
  WHERE (`a`.`orderGID` = `b`.`gID`)